# CS433 Programming Assignment 3

In this assignment, you will implement some basic scheduling algorithms discussed in the class. It is based on the programming project in chapter 5 of the textbook. 

Complete the implementations of scheduling algorithms in the provided source files, and remove "TODO"s from the comments after you are done. Read on the course website for more details and submission instructions. 
